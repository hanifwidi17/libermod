<?php
    include('auth.php');
    remove_session();
?>